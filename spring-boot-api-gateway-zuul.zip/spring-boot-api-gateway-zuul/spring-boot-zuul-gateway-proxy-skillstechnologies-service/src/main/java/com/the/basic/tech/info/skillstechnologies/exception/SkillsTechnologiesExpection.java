package com.the.basic.tech.info.skillstechnologies.exception;

public class SkillsTechnologiesExpection {
 //Exception handling framework
}
