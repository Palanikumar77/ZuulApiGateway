package com.the.basic.tech.info.skillstechnologies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillsTechnologiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillsTechnologiesApplication.class, args);
	}

}

